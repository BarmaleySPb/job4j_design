# job4j_design

![Build Status](https://travis-ci.com/BarmaleySPb/job4j_design.svg?branch=master)
![codecov](https://codecov.io/gh/BarmaleySPb/job4j_design/branch/master/graph/badge.svg?token=r6X9sq4clV)